# social-media-app
Social media app but with new features like translate messages and posts , support video &amp; images as posts  , chat and  notifications , etc... 
# Features:
- It's social media app  you can publish post, set like or comment, support videos and images 
- notification for new messeages  
- The app is geting data form firebase 
- The best perfomance 
- And all of these in One Activity  (one activity app)
- detect language 
- and translate differnce language to your language 


# Login - registration 
  <img src="https://user-images.githubusercontent.com/62241386/168599243-a99f54bb-5f5c-46b6-9ff1-7924be49abb3.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599251-eef09c1e-8fa3-4b09-9eed-7b293a073091.png" width="200">&nbsp; 
  
  
  # Screenshots for dashboard 
  
  <img src="https://user-images.githubusercontent.com/62241386/168599864-2bd66ae6-c217-4b7a-8b98-b4a4726a576c.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599853-cd597c2e-c3e1-441f-9131-1bfbff27dbdd.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599842-42a9eeba-a299-41fc-a47a-46bbdd106e54.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599867-a6988c7d-cd10-4acc-bda7-342b1d4f1772.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599887-860da2f1-f16b-4ad7-89e7-e6c64a69811c.png" width="200">&nbsp; 
  <img src="https://user-images.githubusercontent.com/62241386/168599899-e39652f2-4d0e-4662-bc65-f67eedf95de0.png" width="200">&nbsp;
  <img src="https://user-images.githubusercontent.com/62241386/168599913-b17e8776-defc-4740-847d-632f9dbb8fb7.png" width="200">&nbsp;
    
    
  # Post can be translated to your langauge 
  <img src="https://user-images.githubusercontent.com/62241386/168600950-83df8cc9-acc4-48a2-96dc-e5badbdb6273.png" width="200">&nbsp;
  <img src="https://user-images.githubusercontent.com/62241386/168600946-152699b8-9884-4698-97db-0f17344c3142.png" width="200">&nbsp;


# Messenger 
  <img src="https://user-images.githubusercontent.com/62241386/168601389-842751e1-6d02-46ab-9d6f-7be8e3a54d72.png" width="200">&nbsp;
  <img src="https://user-images.githubusercontent.com/62241386/168601369-807f84e0-b607-41be-8e77-b89a7bd473f6.png" width="200">&nbsp;
  
  ## The message translated automatically for user language 
  <img src="https://user-images.githubusercontent.com/62241386/168601404-2078f821-b625-4df1-bb65-939e13878e67.png" width="200">&nbsp;
  <img src="https://user-images.githubusercontent.com/62241386/168601430-77792a95-d371-428b-9526-e6e1104601b2.jpg" width="200">&nbsp;

  
  # Notification 
  <img src="https://user-images.githubusercontent.com/62241386/168601413-f506f843-56cf-4612-a195-6cdf3e212f39.jpg" width="200">&nbsp;



# <img src="https://media.giphy.com/media/5WILqPq29TyIkVCSej/giphy.gif" width="50">  Tools: 
- Kotlin
- MVVM , clean code
- Dagger Hilt
- viewModel , LiveData
- Coroutines
- Navigation component
- Glide
- Exo player for videos 
- Notification 
- Cloud messaging
# Machine Learning
 * to Detect the language of text 
 * to Translate text from one language to another

