package com.example.socialmediaapp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}